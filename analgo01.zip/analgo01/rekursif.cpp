#include <iostream>
#include <cstdlib>
#include <chrono>

using namespace std;
using namespace std::chrono;


int pangkat(int a, int N ){
 if (N==0){
  return (1);
 }
 else{
  return (a*pangkat (a, N-1));
 }
}

int main(int argc, char *argv[]) {
	
	    high_resolution_clock::time_point t1 = high_resolution_clock::now();
	
 int b =2, x =3, hasil_pangkat;
 cout<<"Bilangan yang dipangkatkan : "<<b;
 hasil_pangkat = pangkat(b, x);
 cout<<"x = "<<x<<endl<<endl;
 cout<<"b^x = "<<b<<"^"<<x<<endl;
 cout<<"    = "<<hasil_pangkat<<"\n";

high_resolution_clock::time_point t2 = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>( t2 - t1 ).count();
    cout<<duration <<" microseconds" <<endl;

}