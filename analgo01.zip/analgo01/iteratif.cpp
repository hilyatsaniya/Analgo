#include<iostream>
#include <chrono>

using namespace std;
using namespace std::chrono;

int pangkat (int a, int b)
    {int hasil=1;
    for (int i=1;i<=b;i++)
    {
       hasil=hasil*a;
         }
    return hasil;
    }
    
int main()
{
		    high_resolution_clock::time_point t1 = high_resolution_clock::now();

    int i =2,j=33;
    
    
    cout<<"PROGRAM MENGHITUNG PANGKAT"<<endl;
    cout<<endl<<"Angka : " <<i;
    cout<<endl<<"Pangkat : "<<j;
    cout<<endl<<"Hasilnya = ";
    cout<<pangkat(i,j)<<"\n";
     
     
high_resolution_clock::time_point t2 = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>( t2 - t1 ).count();
    cout<<duration <<" microseconds" <<endl;

    

}
